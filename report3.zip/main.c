#include "student.h"

void dbcreate(char *);
void dbquery(char *);
void dbupdate(char *);

int main(int argc, char *argv[]) {
	int selection;
	
	if(argc < 2) {
		fprintf(stderr, "사용법 : %s file\n", argv[0]);
		exit(1);
	}

	while(1) {
		printf("1. db 생성\n2. db 질의\n3. db 갱신\n0. 종료\n");
		printf("메뉴 선택 >>> \n");
		scanf("%d", &selection);

		if(selection == 1) {
			dbcreate(argv[1]);
		}
		
		else if(selection == 2) {
			dbquery(argv[1]);
		}

		else if(selection == 3) {
			dbupdate(argv[1]);
		}

		else if(selection == 0) {
			exit(0);
		}
		
		else {
			printf("잘못된 값입니다. 다시 입력해주세요.\n");
		}
	}
}
